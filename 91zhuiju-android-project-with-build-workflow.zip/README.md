# 91追剧 Android WebView App

此项目把 `https://www.91zhuiju.cc/` 包装为 Android WebView 应用。

## 使用方法
1. 安装 Android Studio（建议使用带 Android SDK 的近期稳定版）。
2. 解压项目，在 Android Studio 中选择 **Open**，打开 `91zhuiju-android` 文件夹。
3. 等待 Gradle 同步。如果提示安装 Android SDK Platform 35，请按提示安装。
4. 在真机或模拟器运行测试。
5. 生成 APK：**Build → Build Bundle(s) / APK(s) → Build APK(s)**。
6. Debug APK 通常输出到 `app/build/outputs/apk/debug/app-debug.apk`。

## 项目配置
- App 名称：91追剧
- Application ID：`cc.zhuiju.app`
- 启动网址：`https://www.91zhuiju.cc/`
- 允许在 WebView 内打开的主站域名：`www.91zhuiju.cc` 和 `91zhuiju.cc`

如果网站登录、播放、跳转或下载使用其他自有子域名，需要审查后将该域名加入 `allowedHosts`。不要把任意第三方域名全部加入白名单。
视频全屏已加入基础支持；网站自身的播放器、DRM、弹窗、验证码及跨域登录仍需真机测试。
